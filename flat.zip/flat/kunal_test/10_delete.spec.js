
var DELETE = require('../src/lambda/flat/DELETE');
const logger = Object.assign({}, console);
const expect = require('chai').expect;

// function deleteFlat() {
    describe('DELETE test-cases', function () {
        describe('Delete flat test correct data check', function () {
            var deleteJSON_valid_delete_flat = {
                "httpMethod": "DELETE",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "buildingName": "B"
                }
            };
            it('should delete flat record else throw error', function (done) {
                closure_separate_delete_function_execution(deleteJSON_valid_delete_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            })
        });

        // describe('Delete flat test incorrect data check', function () {
        //     var deleteJSON_valid_delete_flat = {
        //         "httpMethod": "DELETE",
        //         "body": {
        //             "active": "true",
        //             "flatId": "B41",
        //             "buildingName": "B"
        //         }
        //     };
        //     it('should not delete flat record', function (done) {
        //         closure_separate_delete_function_execution(deleteJSON_valid_delete_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     })
        // });

        describe('Delete flat test missing property "active" check', function () {
            var deleteJSON_valid_delete_flat = {
                "httpMethod": "DELETE",
                "body": {
                    "flatId": "C31",
                    "buildingName": "C"
                }
            };
            it('should not delete flat record because property "active" is missing', function (done) {
                closure_separate_delete_function_execution(deleteJSON_valid_delete_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error("property 'active' is missing"));
                        done();
                    }
                });
            })
        });

        describe('Delete flat test missing property "flatId" check', function () {
            var deleteJSON_valid_delete_flat = {
                "httpMethod": "DELETE",
                "body": {
                    "active": "true",
                    "buildingName": "G"
                }
            };
            it('should not delete flat record because property "flatId" is missing', function (done) {
                closure_separate_delete_function_execution(deleteJSON_valid_delete_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error("property 'flatId' is missing"));
                        done();
                    }
                });
            })
        });

        describe('Delete flat test missing property "buildingName" check', function () {
            var deleteJSON_valid_delete_flat = {
                "httpMethod": "DELETE",
                "body": {
                    "active": "true",
                    "flatId": "931"
                }
            };
            it('should not delete flat record because property "buildingName" is missing', function (done) {
                closure_separate_delete_function_execution(deleteJSON_valid_delete_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error("property 'buildingName' is missing"));
                        done();
                    }
                });
            })
        });
    });
// }

function closure_separate_delete_function_execution(deleteJSON_valid_delete_flat, cb) {
    console['log'] = function () { return {} };
    DELETE.execute(deleteJSON_valid_delete_flat.body,  function (error, data) {
        if (error) {
            // console['log'] = logger.log;
            cb(error);
        }
        else {
            console['log'] = logger.log;
            cb(null, data);
        }
    })
}

// module.exports = { deleteFlat }