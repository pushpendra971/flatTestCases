// const request = require('request');
// const expect = require('chai').expect;
// const config = require('../offline/config');
// const baseUrl = "http://" + config.url + ":8988/kunal/flat/flat";

// // function addFlat() {
//     describe('INSERT FLAT ENDPOINT TEST', function () {
//         it('add flat record', function (done) {
//             request.post(baseUrl, {
//                 json: {
//                     "active": "true",
//                     "flatId": "B31",
//                     "floorNo": "3",
//                     "flatType": "3-BHK",
//                     "flatStatus": "available",
//                     "pricePerSquare": "3100",
//                     "area": "143.82",
//                     "buildingName": "B",
//                     "features": ["Balcony", "Gym", "Terrace"]
//                 }
//             }, function (error, response, body) {
//                 if (error) {
//                     expect(error.statusCode).to.equal(400);
//                     // console.log(error);
//                     done();
//                 }
//                 else {
//                     if (body.statusCode == 400) {
//                         expect(response.body.statusCode).to.equal(400);
//                         // console.log(body);
//                         // done(new Error(body.body));
//                         done();
//                     }
//                     else {
//                         expect(response.body.statusCode).to.equal(200);
//                         // console.log(body);
//                         done();
//                     }
//                 }
//             })
//         })
//     })
// // }

// // module.exports = { addFlat }