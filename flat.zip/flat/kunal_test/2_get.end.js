// var request = require('request');
// var expect = require('chai').expect;
// var config = require('../offline/config');
// var baseUrl = "http://" + config.url + ":8988/kunal/flat/flat?active=true&flatId=B31";
// // console.log(baseUrl)

// // function getFlat() {
// describe("GET FLAT ENDPOINT TEST",function(){
//     it("returns flat data",function(done){
//         request.get(baseUrl,{},function(error,response,body){
//             // console.log(error,response,body);
//             if(error){
//                 expect(error.statusCode).to.equal(400);
//                 // console.log(error);
//                 done();
//             }
//             else{
//                 response.body = JSON.parse(response.body);
//                 if(response.body.statusCode == 400){
//                     expect(response.body.statusCode).to.equal(400);
//                     // console.log(body);
//                     // done(new Error(body.body));
//                     done();
//                 }
//                 else{
//                     expect(response.body.statusCode).to.equal(200);
//                     // console.log(body);
//                     done();
//                 }
//             }
//         })
//     })
// })
//     // }

//     // module.exports = { getFlat };