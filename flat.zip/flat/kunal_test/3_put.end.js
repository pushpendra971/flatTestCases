// const request = require('request');
// const expect = require('chai').expect;
// const config = require('../offline/config');
// const baseUrl = "http://" + config.url + ":8988/kunal/flat/flat";

// // function updateFlat() {
//     describe('UPDATE FLAT ENDPOINT TEST', function () {
//         it('updates flat record', function (done) {
//             request.put(baseUrl, {
//                 json: {
//                     "active": "true",
//                     "flatId": "B31",
//                     "flatStatus": "reserved",
//                     "buildingName": "B"
//                 }
//             }, function (error, response, body) {
//                 if (error) {
//                     expect(error.statusCode).to.equal(400);
//                     // console.log(error);
//                     done();
//                 }
//                 else {
//                     if (body.statusCode == 400) {
//                         expect(response.body.statusCode).to.equal(400);
//                         // console.log(body);
//                         // done(new Error(body.body));
//                         done();
//                     }
//                     else {
//                         expect(response.body.statusCode).to.equal(200);
//                         // console.log(body);
//                         done();
//                     }
//                 }
//             })
//         })
//     })
// // }

// // module.exports = { updateFlat }