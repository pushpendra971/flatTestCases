// const request = require('request');
// const expect = require('chai').expect;
// const config = require('../offline/config');
// const baseUrl = "http://" + config.url + ":8988/kunal/flat/flat";

// // function deleteFlat() {
//     describe('DELETE FLAT ENDPOINT TEST', function () {
//         it('delete flat record', function (done) {
//             request.del(baseUrl, {
//                 json: {
//                     "active": "true",
//                     "flatId": "B31",
//                     "buildingName": "B"
//                 }
//             }, function (error, response, body) {
//                 if (error) {
//                     expect(error.statusCode).to.equal(400);
//                     // console.log(error);
//                     done();
//                 }
//                 else {
//                     if (body.statusCode == 400) {
//                         expect(response.body.statusCode).to.equal(400);
//                         // console.log(body);
//                         // done(new Error(body.body));
//                         done();
//                     }
//                     else {
//                         expect(response.body.statusCode).to.equal(200);
//                         // console.log(body);
//                         done();
//                     }
//                 }
//             })
//         })
//     })
// // }

// // module.exports = { deleteFlat }