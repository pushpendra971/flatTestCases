
var POST = require('../src/lambda/flat/POST');
const logger = Object.assign({}, console);
const expect = require('chai').expect;
// addFlat();
// function addFlat() {
    describe('POST test-cases', function () {
        describe('Insert flat record check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "floorNo": "3",
                    "flatType": "3-BHK",
                    "flatStatus": "available",
                    "pricePerSquare": "3100",
                    "area": "143.82",
                    "buildingName": "B",
                    "features": ["Balcony", "Gym", "Terrace"]
                }
            };
            it('should insert flat record else throw error', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else
                    {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            })
        });

        // describe('Insert flat record incorrect data check', function () {
        //     var postJSON_valid_add_flat = {
        //         "httpMethod": "POST",
        //         "body": {
        //             "active": "true",
        //             "flatId": "B31",
        //             "floorNo": "3",
        //             "flatType": "3-BHK",
        //             "flatStatus": "available",
        //             "pricePerSquare": "3100",
        //             "area": "143.82",
        //             "buildingName": "B",
        //             "features": ["Balcony", "Gym", "Terrace"]
        //         }
        //     };
        //     it('should not insert flat record', function (done) {
        //         closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     })
        // });
        describe('Insert flat test missing property "active" check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "flatId": "B31",
                    "floorNo": "3",
                    "flatType": "3-BHK",
                    "flatStatus": "available",
                    "pricePerSquare": "3100",
                    "area": "143.82",
                    "buildingName": "B",
                    "features": ["Balcony", "Gym", "Terrace"]
                }
            };
            it('should not insert flat record because property "active" is missing', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "active" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Insert flat test missing property "flatId" check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "active": "true",
                    "floorNo": "3",
                    "flatType": "3-BHK",
                    "flatStatus": "available",
                    "pricePerSquare": "3100",
                    "area": "143.82",
                    "buildingName": "B",
                    "features": ["Balcony", "Gym", "Terrace"]
                }
            };
            it('should not insert flat record because property "flatId" is missing', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "flatId" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Insert flat test missing property "floorNo" check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "flatType": "3-BHK",
                    "flatStatus": "available",
                    "pricePerSquare": "3100",
                    "area": "143.82",
                    "buildingName": "B",
                    "features": ["Balcony", "Gym", "Terrace"]
                }
            };
            it('should not insert flat record because property "floorNo" is missing', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "floorNo" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Insert flat test missing property "flatType" check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "floorNo": "3",
                    "flatStatus": "available",
                    "pricePerSquare": "3100",
                    "area": "143.82",
                    "buildingName": "B",
                    "features": ["Balcony", "Gym", "Terrace"]
                }
            };
            it('should not insert flat record because property "flatType" is missing', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "flatType" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Insert flat test missing property "flatStatus" check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "floorNo": "3",
                    "flatType": "3-BHK",
                    "pricePerSquare": "3100",
                    "area": "143.82",
                    "buildingName": "B",
                    "features": ["Balcony", "Gym", "Terrace"]
                }
            };
            it('should not insert flat record because property "flatStatus" is missing', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "flatStatus" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Insert flat test missing property "pricePerSquare" check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "floorNo": "3",
                    "flatType": "3-BHK",
                    "flatStatus": "available",
                    "area": "143.82",
                    "buildingName": "B",
                    "features": ["Balcony", "Gym", "Terrace"]
                }
            };
            it('should not insert flat record because property "pricePerSquare" is missing', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "pricePerSquare" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Insert flat test missing property "area" check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "floorNo": "3",
                    "flatType": "3-BHK",
                    "flatStatus": "available",
                    "pricePerSquare": "3100",
                    "buildingName": "B",
                    "features": ["Balcony", "Gym", "Terrace"]
                }
            };
            it('should not insert flat record because property "area" is missing', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "area" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Insert flat test missing property "buildingName" check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "floorNo": "3",
                    "flatType": "3-BHK",
                    "flatStatus": "available",
                    "pricePerSquare": "3100",
                    "area": "143.82",
                    "features": ["Balcony", "Gym", "Terrace"]
                }
            };
            it('should not insert flat record because property "buildingName" is missing', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "buildingName" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Insert flat test missing property "features" check', function () {
            var postJSON_valid_add_flat = {
                "httpMethod": "POST",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "floorNo": "3",
                    "flatType": "3-BHK",
                    "flatStatus": "available",
                    "pricePerSquare": "3100",
                    "area": "143.82",
                    "buildingName": "B"
                }
            };
            it('should not insert flat record because property "features" is missing', function (done) {
                closure_separate_insert_function_execution(postJSON_valid_add_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "features" is missing'));
                        done();
                    }
                });
            })
        });
    });
// }

function closure_separate_insert_function_execution(postJSON_valid_add_flat, cb) {
    console['log'] = function () { return {} };
    POST.execute( postJSON_valid_add_flat.body,  function (error, data) {
        if (error) {
            // console['log'] = logger.log;
            cb(error);
        }
        else {
            console['log'] = logger.log;
            cb(null, data);
        }
    })
}

// module.exports = { addFlat }