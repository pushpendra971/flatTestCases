
var PUT = require('../src/lambda/flat/UPDATE');
const logger = Object.assign({}, console);
const expect = require('chai').expect;
const assert = require('chai').assert;

// function updateFlat() {
    describe('PUT test-cases', function () {
        describe('Update flat test check', function () {
            var putJSON_valid_update_flat = {
                "httpMethod": "PUT",
                "body": {
                    "active": "true",
                    "flatId": "B31",
                    "buildingName": "B",
                    "flatStatus": "reserved"
                }
            };
            it("should update flat record else throw error", function (done) {
                closure_separate_update_function_execution(putJSON_valid_update_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            })
            it("checks response-data type", function (done) {
                closure_separate_update_function_execution(putJSON_valid_update_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        var item = JSON.parse(data.body);
                        // logger.log(item.data);
                        assert.typeOf(item.data.active, "string");
                        assert.typeOf(item.data.flatId, "string");
                        assert.typeOf(item.data.floorNo, "number");
                        assert.typeOf(item.data.flatType, "string");
                        assert.typeOf(item.data.flatStatus, "string");
                        assert.typeOf(item.data.features, "array");
                        assert.typeOf(item.data.pricePerSquare, "number");
                        assert.typeOf(item.data.buildingName, "string");
                        assert.typeOf(item.data.area, "number");
                        assert.typeOf(item.data.totalPrice, "number");
                        done();
                    }
                })
            })
        });

        // describe('Update flat test incorrect data check', function () {
        //     var putJSON_valid_update_flat = {
        //         "httpMethod": "PUT",
        //         "body": {
        //             "active": "true",
        //             "flatId": "F31",
        //             "buildingName": "F",
        //             "flatStatus": "available"
        //         }
        //     };
        //     it("should not update flat record because flat doesn't exists", function (done) {
        //         closure_separate_update_function_execution(putJSON_valid_update_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     })
        // });

        describe('Update flat test missing property "active" check', function () {
            var putJSON_valid_update_flat = {
                "httpMethod": "PUT",
                "body": {
                    "flatId": "C31",
                    "buildingName": "C",
                    "flatStatus": "available"
                }
            };
            it('should not update flat record because property "active" is missing', function (done) {
                closure_separate_update_function_execution(putJSON_valid_update_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "active" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Update flat test missing property "flatId" check', function () {
            var putJSON_valid_update_flat = {
                "httpMethod": "PUT",
                "body": {
                    "active": "true",
                    "buildingName": "G",
                    "flatStatus": "available"
                }
            };
            it('should not update flat record because property "flatId" is missing', function (done) {
                closure_separate_update_function_execution(putJSON_valid_update_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "flatId" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Update flat test missing property "buildingName" check', function () {
            var putJSON_valid_update_flat = {
                "httpMethod": "PUT",
                "body": {
                    "active": "true",
                    "flatId": "931",
                    "flatStatus": "available"
                }
            };
            it('should not update flat record because property "buildingName" is missing', function (done) {
                closure_separate_update_function_execution(putJSON_valid_update_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "buildingName" is missing'));
                        done();
                    }
                });
            })
        });

        describe('Update flat test missing property "flatStatus" check', function () {
            var putJSON_valid_update_flat = {
                "httpMethod": "PUT",
                "body": {
                    "active": "true",
                    "flatId": "A41",
                    "buildingName": "A"
                }
            };
            it('should not update flat record because property "flatStatus" is missing', function (done) {
                closure_separate_update_function_execution(putJSON_valid_update_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data, null, 6));
                        // done(new Error('property "flatStatus" is missing'));
                        done();
                    }
                });
            })
        });
    });
// }

function closure_separate_update_function_execution(putJSON_valid_update_flat, cb) {
    console['log'] = function () { return {} };
    PUT.execute( putJSON_valid_update_flat.body,{}, function (error, data) {
        if (error) {
            // console['log'] = logger.log;
            cb(error);
        }
        else {
            console['log'] = logger.log;
            cb(null, data);
        }
    })
}

// module.exports = { updateFlat }