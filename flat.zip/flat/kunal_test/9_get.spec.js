


var GET = require('../src/lambda/flat/GET');
const logger = Object.assign({}, console);
const expect = require('chai').expect;
const assert = require('chai').assert;

// function getFlat() {
     describe('GET test-cases', function () {
        describe('GET single flat check', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "active": "true",
                    "flatId": "B31"
                }
            };
            it("should return flat data else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            })

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done(error);
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        var item = JSON.parse(data.body);
                        // logger.log(item.data);
                        assert.typeOf(item.data.active, "string");
                        assert.typeOf(item.data.flatId, "string");
                        done();
                    }
                });
            })
        });

        // describe('GET single flat incorrect details check', function () {
        //     var getJSON_valid_get_all_flat = {
        //         "httpMethod": "GET",
        //         "queryStringParameters": {
        //             "active": "true",
        //             "flatId": "A08"
        //         }
        //     };
        //     it("should not return flat data", function (done) {
        //         closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     })
        // });

        describe('GET flats via property "active" & features check ', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "active": "true",
                    "features": "Parking"
                }
            };

            it("should return flat data filtered by features else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            });

            it('active should be one of the allowed values: "true || false"', function () {
                expect(getJSON_valid_get_all_flat.queryStringParameters.active).to.be.oneOf(['true', 'false']);
            });

            it('Feature name should be string', function () {
                assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.features, "string");
            });

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            })
        });

        describe('GET flats via property "active", floorNo & features check ', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "active": "true",
                    "features": "Parking",
                    "floorNo": "0"
                }
            };

            it("should return flat data filtered by features and floorNo else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            });

            it('active should be one of the allowed values: "true || false"', function () {
                expect(getJSON_valid_get_all_flat.queryStringParameters.active).to.be.oneOf(['true', 'false']);
            });

            it('Feature name should be string', function () {
                assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.features, "string");
            });

            it("floorNo should be one of the allowed values:0||1||2||3", function (done) {
                expect(getJSON_valid_get_all_flat.queryStringParameters.floorNo).to.be.oneOf(['0', '1', '2', '3']);
                done();
            });

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done(error);
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            })
        });

        describe('GET flats via features check ', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "features": "Gym"
                }
            };

            it("should return flat data filtered by features else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            });
            it('Feature name should be string', function () {
                assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.features, "string");
            });

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            })
        });

        describe('GET flats via property "active" check', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "active": "true"
                }
            };
            it("should be one of allowed values: true||false", function (done) {
                expect(getJSON_valid_get_all_flat.queryStringParameters.active).to.be.oneOf(['true', 'false']);
                done();
            });
            it("should return flat data by satisfying given property else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            });
            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done(error);
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            })
            it('should be of type - string', function () {
                assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.active, "string");
            });
        });

        // describe('GET flats via invalid value of property "active" check', function () {
        //     var getJSON_valid_get_all_flat = {
        //         "httpMethod": "GET",
        //         "queryStringParameters": {
        //             "active": "none"
        //         }
        //     };
        //     it("should not return flat data because given property is not satisfied", function (done) {
        //         closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     });
        // });

        describe('GET flat via floorNo check ', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "floorNo": "2"
                }
            };

            it("should return flat data else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            });

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            })

            it('should be string type', function () {
                assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.floorNo, "string");
            });

            it("should be one of the allowed values:0||1||2||3", function (done) {
                expect(getJSON_valid_get_all_flat.queryStringParameters.floorNo).to.be.oneOf(['0', '1', '2', '3']);
                done();
            });
        });

        // describe('GET flat via invalid "floorNo" check ', function () {
        //     var getJSON_valid_get_all_flat = {
        //         "httpMethod": "GET",
        //         "queryStringParameters": {
        //             "floorNo": "4"
        //         }
        //     };

        //     it("should not return flat data because 'floorNo' is invalid", function (done) {
        //         closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     });
        // });

        describe('GET flat via flat-type check ', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "flatType": "2-BHK"
                }
            };

            it("should return flat data else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });

            });

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            });

            it('flatType should be string', function () {
                assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.flatType, "string");
            });

            it("should be allowed values: 1-BHK || 2-BHK || 3-BHK", function (done) {
                expect(getJSON_valid_get_all_flat.queryStringParameters.flatType).to.be.oneOf(['1-BHK', '2-BHK', '3-BHK']);
                done();
            });
        });

        // describe('GET flat via invalid flat-type check ', function () {
        //     var getJSON_valid_get_all_flat = {
        //         "httpMethod": "GET",
        //         "queryStringParameters": {
        //             "flatType": "4BHK"
        //         }
        //     };

        //     it("should not return flat data because flat-type is invalid", function (done) {
        //         closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     });
        // });

        describe('GET flat via flat-status check ', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "flatStatus": "sold"
                }
            };

            it("should return flat data else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            })

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            });

            it('should be string type', function () {
                assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.flatStatus, "string");
            });

            it("flatStatus should be one of allowed values: available || reserved || sold ", function (done) {
                expect(getJSON_valid_get_all_flat.queryStringParameters.flatStatus).to.be.oneOf(['available', 'reserved', 'sold']);
                done();
            });
        });

        // describe('GET flat via invalid flat-status check ', function () {
        //     var getJSON_valid_get_all_flat = {
        //         "httpMethod": "GET",
        //         "queryStringParameters": {
        //             "flatStatus": "none"
        //         }
        //     };

        //     it("should not return flat data because flat status is invalid", function (done) {
        //         closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     })
        // });

        describe('GET flat data via pagination check ', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "lastevaluatedkeyactive": "",
                    "lastevaluatedkeyflatId": "",
                    "lastevaluatedkeytotalPrice": ""
                }
            };

            it("should return flat data", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            })

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            });
        });

        describe('GET flat data via property "active" & pagination check ', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "active": "true",
                    "lastevaluatedkeyactive": "",
                    "lastevaluatedkeyflatId": "",
                    "lastevaluatedkeytotalPrice": ""
                }
            };

            it("should return flat data else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            })

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            });
        });

        // describe('GET flat data via invalid value of property "active" & pagination check ', function () {
        //     var getJSON_valid_get_all_flat = {
        //         "httpMethod": "GET",
        //         "queryStringParameters": {
        //             "active": "none",
        //             "lastevaluatedkeyactive": "C02",
        //             "lastevaluatedkeyflatId": "true",
        //             "lastevaluatedkeytotalPrice": "137457"
        //         }
        //     };

        //     it("should not return flat data because of invalid value of property 'active'", function (done) {
        //         closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     })
        // });

        describe('GET flat via "active" & priceSort check ', function () {
            var getJSON_valid_get_all_flat = {
                "httpMethod": "GET",
                "queryStringParameters": {
                    "active": "true",
                    "priceSort": "true"
                }
            };

            it("should return sorted flat data through price else throw error", function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        // logger.log(JSON.stringify(data, null, 6));
                        done();
                    }
                });
            })

            it('check valid response-data type', function (done) {
                closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
                    if (error) {
                        expect(error.statusCode).to.equal(400);
                        // logger.log(error);
                        done();
                    }
                    else if(data.statusCode == 400){
                        expect(data.statusCode).to.equal(400);
                        // logger.log(JSON.stringify(data,null,6));
                        // done(new Error(data.body));
                        done();
                    }
                    else {
                        expect(data.statusCode).to.equal(200);
                        get_valid_response_check(data, function () {
                            done();
                        })
                    }
                });
            });

            it('should be string : true || false', function () {
                assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.priceSort, "string");
            });
        });

        // describe('GET flat data via "active" & invalid value of priceSort check ', function () {
        //     var getJSON_valid_get_all_flat = {
        //         "httpMethod": "GET",
        //         "queryStringParameters": {
        //             "active": "true",
        //             "priceSort": "none"
        //         }
        //     };

        //     it("should not return flat data because of invalid value of priceSort", function (done) {
        //         closure_separate_get_function_execution(getJSON_valid_get_all_flat, function (error, data) {
        //             if (error) {
        //                 expect(error.statusCode).to.equal(400);
        //                 logger.log(error);
        //                 done();
        //             }
        //             else {
        //                 expect(data.statusCode).to.equal(400);
        //                 logger.log(JSON.stringify(data, null, 6));
        //                 done();
        //             }
        //         });
        //     })
        // });
    });
// }


function closure_separate_get_function_execution(getJSON_valid_get_all_flat, cb) {
    console['log'] = function () { return {} };
    GET.execute( getJSON_valid_get_all_flat.queryStringParameters,  function (error, data) {
        if (error) {
            // console['log'] = logger.log;
            cb(error);
        }
        else {
            console['log'] = logger.log;
            cb(null, data);
        }
    })
}

function get_valid_response_check(data, call) {
    var item = JSON.parse(data.body);
    var len = item.data.length;
    // logger.log(len);

    if (len == 0) {
        call();
    }
    else {
        for (i = 0; i < len; i++) {
            assert.typeOf(item.data[i].active, "string");
            assert.typeOf(item.data[i].flatId, "string");
            assert.typeOf(item.data[i].floorNo, "number");
            assert.typeOf(item.data[i].flatType, "string");
            assert.typeOf(item.data[i].flatStatus, "string");
            assert.typeOf(item.data[i].features, "array");
            assert.typeOf(item.data[i].pricePerSquare, "number");
            assert.typeOf(item.data[i].buildingName, "string");
            assert.typeOf(item.data[i].area, "number");
            assert.typeOf(item.data[i].totalPrice, "number");
        }
        call();
    }
}

// module.exports = { getFlat }