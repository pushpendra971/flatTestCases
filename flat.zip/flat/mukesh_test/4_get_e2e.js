// var request = require('request');
// var expect = require('chai').expect;
// const baseurl = "http://192.168.5.123:8956/mukesh/flat/flat?flatType=3-BHK&floorNo=1";
// console.log("**************************************4 GET E2E TESTING*********************************");
// describe('get data', function () {
//     it('after update get end to end', function (done) {
//         request.get({ uri: baseurl },
//             function (err, response, body) {
//                 expect(response.statusCode).to.equal(200);
//                 // console.log(body);
//                 done();
//             });
//     });
// });