var DELETE = require('../src/lambda/flat/DELETE');
const logger = Object.assign({}, console);
var expect = require('chai').expect;
var assert = require('chai').assert;
console.log("*************************DELETE-API-TESTING***************************");
describe('DELETE test-cases', function () {
    describe('DELETE flat via flat Id check ', function () {
        var deleteJSON_valid_delete_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43"
            }
        };
        it('should be string', function (done) {
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.flatId, 'string');
            done();
        });
        it("active should be required", function (done) {
            closure_separate_function_execution(deleteJSON_valid_delete_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('DELETE flat via flat id and active check ', function () {
        var deleteJSON_valid_delete_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h23",
                "active": "true"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(deleteJSON_valid_delete_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('should be string', function (done) {
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.active, 'string');
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.flatId, 'string');
            done();
        });
        it("building name should be reuired", function (done) {
            closure_separate_function_execution(deleteJSON_valid_delete_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('DELETE flat via flat building name check ', function () {
        var deleteJSON_valid_delete_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "123",
                "active": "true",
                "buildingName": "h"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(deleteJSON_valid_delete_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('should be string', function (done) {
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.active, 'string');
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.flatId, 'string');
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.buildingName, 'string');
            done();
        });
        it("flat does not exits", function (done) {
            closure_separate_function_execution(deleteJSON_valid_delete_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('DELETE flat via flat Id ,active,floor no and  building name check ', function () {
        var deleteJSON_valid_delete_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43",
                "active": "true",
                "buildingName": "h",
                "floorNo": "1"
            }
        };
        it('should be string', function (done) {
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.flatId, 'string');
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.active, 'string');
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.buildingName, 'string');
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.floorNo, 'string');
            done();
        });
        it("should not have additional properties.. only active,flatId and building name is required", function (done) {
            closure_separate_function_execution(deleteJSON_valid_delete_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('DELETE flat via flat building name check ', function () {
        var deleteJSON_valid_delete_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "y5",
                "active": "true",
                "buildingName": "y"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(deleteJSON_valid_delete_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('should be string', function (done) {
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.flatId, 'string');
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.active, 'string');
            assert.typeOf(deleteJSON_valid_delete_all_flat.body.buildingName, 'string');
            done();
        });
        it("flat deleted succesfully", function (done) {
            closure_separate_function_execution(deleteJSON_valid_delete_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    done();
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.body));
                }
            });
        });
    });
});

function closure_separate_function_execution(deleteJSON_valid_delete_all_flat, cb) {
    console['log'] = function () { return {} };
    DELETE.execute(deleteJSON_valid_delete_all_flat.body, function (error, data) {
        if (error) {
            //return error;
            cb(error)
        }
        else {
            console['log'] = logger.log;
            // logger.log(data);
            cb(null, data);
        }
    });
};