var GET = require('../src/lambda/flat/GET');
const logger = Object.assign({}, console);
var expect = require('chai').expect;
var assert = require('chai').assert;
console.log("********************************GET-API-TESTING**********************************");
describe('GET test-cases', function () {
    describe('GET flat via active check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "active": "true"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(getJSON_valid_get_all_flat.queryStringParameters.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.active, 'string');
            done();
        });
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    valid_response_check(data, function () {
                        done();
                    });
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.queryStringParameters));
                }
            })
        });
    });
    describe('GET flat via floor no check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "floorNo": "4"
            }
        };
        it('should be string', function (done) {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.floorNo, 'string');
            done();
        });
        it('floorNo should be one of allowed values: 0/1/2/3/4', function (done) {
            expect(getJSON_valid_get_all_flat.queryStringParameters.floorNo).to.be.oneOf(["0", "1", "2", "3", "4"]);
            done();
        });
        it("should return flat data", function (done) {
            // logger.log(JSON.stringify(data, null, 6));
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    valid_response_check(data, function () {
                        done();
                    });
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.queryStringParameters));
                }
            })
        });
    });
    describe('GET flat via floor no check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "floorNo": "5"
            }
        };
        it('floorNo should be string', function (done) {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.floorNo, 'string');
            done();
        });
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done()

            })
        });
    });
    describe('GET flat via flat status check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "flatStatus": "available"
            }
        };
        it('flatStatus should be one of allowed values: available/sold/reserved', function (done) {
            expect(getJSON_valid_get_all_flat.queryStringParameters.flatStatus).to.be.oneOf(["available", "sold", "reserved"]);
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.flatStatus, 'string');
            done();
        });
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    valid_response_check(data, function () {
                        done();
                    });
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.queryStringParameters));
                }
            })
        });
    });
    describe('GET flat via flat type check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "flatType": "1-BHK"
            }
        };
        it('flatType should be one of allowed values: 1-BHK/2-BHK/3-BHK/4-BHK', function (done) {
            expect(getJSON_valid_get_all_flat.queryStringParameters.flatType).to.be.oneOf(["1-BHK", "2-BHK", "3-BHK", "4-BHK"]);
            done();
        });
        it('should be string', function (done) {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.flatType, 'string');
            done();
        });
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    valid_response_check(data, function () {
                        done();
                    });
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.queryStringParameters));
                }
            })
        });

    });
    describe('GET flat via flat type check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "flatType": "1BHK"
            }
        };
        it('should be string', function (done) {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.flatType, 'string');
            done();
        });
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            })
        });
    });
    describe('GET flat via flat features check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "features": "Balcony"
            }
        };
        it('should be string', function (done) {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.features, 'string');
            done();
        });
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    valid_response_check(data, function () {
                        done();
                    });
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.queryStringParameters));
                }
            })
        });
    });
    describe('GET flat via priceSort check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "priceSort": "true"
            }
        };
        it('priceSort should be one of allowed values: true/false', function (done) {
            expect(getJSON_valid_get_all_flat.queryStringParameters.priceSort).to.be.oneOf(["true", "false"]);
            done();
        });
        it('should be string', function (done) {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.priceSort, 'string');
            done();
        });
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    valid_response_check(data, function () {
                        done();
                    });
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.queryStringParameters));
                }
            })
        });
    });
    describe('GET flat via pagination check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "lastEvaluatedKeyflatId": "y10",
                "lastEvaluatedKeytotalPrice": "37000",
                "lastEvaluatedKeyactive": "true"
            }
        };
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    valid_response_check(data, function () {
                        done();
                    });
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.queryStringParameters));
                }
            })
        });
    });
});

function closure_separate_function_execution(getJSON_valid_get_all_flat, cb) {
    console['log'] = function () { return {} };
    GET.execute(getJSON_valid_get_all_flat.queryStringParameters, function (error, data) {
        if (error) {
            //return error;
            cb(error)
        }
        else {
            console['log'] = logger.log;
            // logger.log(data);
            cb(null, data);
        }
    });
};
function valid_response_check(data, call) {
    var item = JSON.parse(data.body);
    var len = item.data.length;
    // logger.log(len);
    for (i = 0; i < len; i++) {
        assert.typeOf(item.data[i].active, "string");
        assert.typeOf(item.data[i].flatId, "string");
        assert.typeOf(item.data[i].floorNo, "number");
        assert.typeOf(item.data[i].flatType, "string");
        assert.typeOf(item.data[i].flatStatus, "string");
        assert.typeOf(item.data[i].features, "array");
        assert.typeOf(item.data[i].pricePerSquare, "number");
        assert.typeOf(item.data[i].buildingName, "string");
        assert.typeOf(item.data[i].area, "number");
        assert.typeOf(item.data[i].totalPrice, "number");
    }
    call();
}