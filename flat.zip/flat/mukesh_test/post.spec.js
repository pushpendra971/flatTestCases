
var POST = require('../src/lambda/flat/POST');
const logger = Object.assign({}, console);
var expect = require('chai').expect;
var assert = require('chai').assert;
console.log("*************************POST-API-TESTING***************************");
describe('POST test-cases', function () {
    describe('POST flat via active check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true"
            }
        };
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flat id should be required", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatId check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y5"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it("building Name should be required", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y5",
                "buildingName": "y"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it("flatType should be required", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName/flatType check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y5",
                "buildingName": "y",
                "flatType": "1-BHK"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('actvie should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatType should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatType, 'string');
            done();
        });
        it("floorNo should be required", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName/flatType/floorNo check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y5",
                "buildingName": "y",
                "flatType": "1-BHK",
                "floorNo": 2
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatType should be string', function (done) {
            ;
            assert.typeOf(postJSON_valid_post_all_flat.body.flatType, 'string');
            done();
        });
        it('floorNo should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.floorNo, 'number');
            done();
        });
        it("flatStatus should be required", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName/flatType/floorNo/flatStatus check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y5",
                "buildingName": "y",
                "flatType": "1-BHK",
                "floorNo": 2,
                "flatStatus": "available"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatType should be string', function (done) {
            ;
            assert.typeOf(postJSON_valid_post_all_flat.body.flatType, 'string');
            done();
        });
        it('floorNo should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.floorNo, 'number');
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatStatus, 'string');
            done();
        });
        it("area should be required", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName/flatType/floorNo/flatSttaus/area check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y5",
                "buildingName": "y",
                "flatType": "1-BHK",
                "floorNo": 2,
                "flatStatus": "available",
                "area": 50
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatType should be string', function (done) {
            ;
            assert.typeOf(postJSON_valid_post_all_flat.body.flatType, 'string');
            done();
        });
        it('floorNo should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.floorNo, 'number');
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatStatus, 'string');
            done();
        });
        it('area should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.area, 'number');
            done();
        });
        it("pricePerSquare should be required", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName/flatType/floorNo/flatSttaus/area/pricePerSquare check', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y5",
                "buildingName": "y",
                "flatType": "1-BHK",
                "floorNo": 2,
                "flatStatus": "available",
                "area": 50,
                "pricePerSquare": 1000
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatType should be string', function (done) {
            ;
            assert.typeOf(postJSON_valid_post_all_flat.body.flatType, 'string');
            done();
        });
        it('floorNo should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.floorNo, 'number');
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatStatus, 'string');
            done();
        });
        it('area should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.area, 'number');
            done();
        });
        it('pricePerSquare should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.pricePerSquare, 'number');
            done();
        });
        it("totalPrice should be required", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName/flatType/floorNo/flatSttaus/area/pricePerSquare/totalPrice check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y5",
                "buildingName": "y",
                "flatType": "1-BHK",
                "floorNo": 2,
                "flatStatus": "available",
                "area": 50,
                "pricePerSquare": 1000,
                "totalPrice": 50000
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatType should be string', function (done) {
            ;
            assert.typeOf(postJSON_valid_post_all_flat.body.flatType, 'string');
            done();
        });
        it('floorNo should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.floorNo, 'number');
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatStatus, 'string');
            done();
        });
        it('area should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.area, 'number');
            done();
        });
        it('pricePerSquare should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.pricePerSquare, 'number');
            done();
        });
        it('totalPrice should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.totalPrice, 'number');
            done();
        });
        it("features should be required", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName/flatType/floorNo/flatSttaus/area/pricePerSquare/totalPrice/features check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y2989225",
                "buildingName": "y",
                "flatType": "1-BHK",
                "floorNo": 2,
                "flatStatus": "available",
                "area": 50,
                "pricePerSquare": 1000,
                "totalPrice": 50000,
                "features": ["Parking", "Gym"]
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatType should be string', function (done) {
            ;
            assert.typeOf(postJSON_valid_post_all_flat.body.flatType, 'string');
            done();
        });
        it('floorNo should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.floorNo, 'number');
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatStatus, 'string');
            done();
        });
        it('area should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.area, 'number');
            done();
        });
        it('pricePerSquare should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.pricePerSquare, 'number');
            done();
        });
        it('totalPrice should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.totalPrice, 'number');
            done();
        });
        it('features should be array', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.features, 'array');
            done();
        });
        it('features should not be null', function (done) {
            assert.isNotNull(postJSON_valid_post_all_flat.body.features, 'Parking')
            done();
        });
        it("flat already exits", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName/flatType/floorNo/flatSttaus/area/pricePerSquare/totalPrice/features/buildingNo check', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y343345",
                "buildingName": "y",
                "flatType": "1-BHK",
                "floorNo": 2,
                "flatStatus": "available",
                "area": 50,
                "pricePerSquare": 1000,
                "totalPrice": 50000,
                "features": ["Parking", "Gym"],
                "buildingNo": 12
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatType should be string', function (done) {
            ;
            assert.typeOf(postJSON_valid_post_all_flat.body.flatType, 'string');
            done();
        });
        it('floorNo should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.floorNo, 'number');
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatStatus, 'string');
            done();
        });
        it('area should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.area, 'number');
            done();
        });
        it('pricePerSquare should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.pricePerSquare, 'number');
            done();
        });
        it('totalPrice should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.totalPrice, 'number');
            done();
        });
        it('features should be array', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.features, 'array');
            done();
        });
        it('features should not be null', function (done) {
            assert.isNotNull(postJSON_valid_post_all_flat.body.features, 'Parking')
            done();
        });
        it("should not have additional properties", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('POST flat via active/flatd/buildingName/flatType/floorNo/flatSttaus/area/pricePerSquare/totalPrice/features check ', function () {
        var postJSON_valid_post_all_flat = {
            "httpMethod": "POST",
            "body": {
                "active": "true",
                "flatId": "y5",
                "buildingName": "y",
                "flatType": "1-BHK",
                "floorNo": 2,
                "flatStatus": "available",
                "area": 50,
                "pricePerSquare": 1000,
                "totalPrice": 50000,
                "features": ["Parking", "Gym"]
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(postJSON_valid_post_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.active, 'string');
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatId, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatType should be string', function (done) {
            ;
            assert.typeOf(postJSON_valid_post_all_flat.body.flatType, 'string');
            done();
        });
        it('floorNo should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.floorNo, 'number');
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.flatStatus, 'string');
            done();
        });
        it('area should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.area, 'number');
            done();
        });
        it('pricePerSquare should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.pricePerSquare, 'number');
            done();
        });
        it('totalPrice should be number', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.totalPrice, 'number');
            done();
        });
        it('features should be array', function (done) {
            assert.typeOf(postJSON_valid_post_all_flat.body.features, 'array');
            done();
        });
        it('features should not be null', function (done) {
            assert.isNotNull(postJSON_valid_post_all_flat.body.features, 'Parking')
            done();
        });
        it("flat created successfully", function (done) {
            closure_separate_function_execution(postJSON_valid_post_all_flat, function (err, data) {
                if(data.statusCode==200){
                    expect(data.statusCode).to.equal(200);
                    done();
                }
                else{
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.body));
                }
            });

        });
    });
});
function closure_separate_function_execution(postJSON_valid_post_all_flat, cb) {
    console['log'] = function () { return {} };
    POST.execute(postJSON_valid_post_all_flat.body, function (error, data) {
        if (error) {
            //return error;
            cb(error)
        }
        else {
            console['log'] = logger.log;
            //  logger.log(data);
            cb(null, data);
        }
    });
};