var UPDATE = require('../src/lambda/flat/UPDATE');
const logger = Object.assign({}, console);
var expect = require('chai').expect;
var assert = require('chai').assert;
console.log("*********************************UPDATE-API-TESTING*********************************");
describe('UPDATE test-cases', function () {
    describe('UPDATE flat via flat Id check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43"
            }
        };
        it('should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it("active should be required", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('UPDATE flat via flat Id and active check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43",
                "active": "true"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(updateJSON_valid_update_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
            done();
        });
        it("buildingName should be required", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('UPDATE flat via flat Id and active check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43",
                "active": "true",
                "buildingName": "h"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(updateJSON_valid_update_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.buildingName, 'string');
            done();
        });
        it("flatStatus should be required", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('UPDATE flat via flat Id and active check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43",
                "active": "true",
                "buildingName": "h",
                "flatStatus": "sold"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(updateJSON_valid_update_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatStatus should be one of allowed values: available/sold/reserved', function (done) {
            expect(updateJSON_valid_update_all_flat.body.flatStatus).to.be.oneOf(['available', 'sold', 'reserved']);
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatStatus, 'string');
            done();
        });
        it("flat doesn't exits", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('UPDATE flat via flat Id,active.buiildingName and flatStatus check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "y5",
                "active": "true",
                "buildingName": "y",
                "flatStatus": "sold"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(updateJSON_valid_update_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatStatus should be one of allowed values: available/sold/reserved', function (done) {
            expect(updateJSON_valid_update_all_flat.body.flatStatus).to.be.oneOf(['available', 'sold', 'reserved']);
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatStatus, 'string');
            done();
        });
        it("New flat updated successfully", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    done();
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.body));
                }
            });
        });
    });
});

function closure_separate_function_execution(getJSON_valid_get_all_flat, cb) {
    console['log'] = function () { return {} };
    UPDATE.execute(getJSON_valid_get_all_flat.body, {}, function (error, data) {
        if (error) {
            //return error;
            cb(error)
        }
        else {
            console['log'] = logger.log;
            // logger.log(data);
            cb(null, data);
        }
    });
};
