
// const request = require('request')
// var expect = require('chai').expect;
// console.log("******************************END_TO_END_POST_TEST******************************");
// describe('POST flat data:', function () {
//     it('add flat', function (done) {
//         request.post('http://192.168.5.123:8989/pushpendra/flat/flat', {
//             json: {
//                 "flatId": "p45",
//                 "active": "true",
//                 "buildingName": "p",
//                 "floorNo": 1,
//                 "flatType": "3-BHK",
//                 "flatStatus": "sold",
//                 "features": ["Parking", "Gym"],
//                 "area": 80.00,
//                 "pricePerSquare": 1000.00,
//                 "totalPrice": 80000.00
//             }
//         }, (error, res, body) => {
//             if (error) {
//                 console.error(error)
//                 return
//             }

//             //console.log(`statusCode: ${res.statusCode}`)
//             expect(res.statusCode).to.equal(200);
//             console.log(body)
//             done();
//         })
//     });
// });
