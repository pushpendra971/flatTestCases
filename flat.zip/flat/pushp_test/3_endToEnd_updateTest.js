// const request = require('request')
// var expect = require('chai').expect;
// console.log("******************************END_TO_END_UPDATE_TEST******************************");
// describe('UPDATE flat data:', function () {
//     it('update flat', function (done) {
//         request.put('http://192.168.5.123:8989/pushpendra/flat/flat', {
//             json: {
//                 "flatId": "p45",
//                 "active": "true",
//                 "flatStatus": "reserved"
//             }
//         }, (error, res, body) => {
//             if (error) {
//                 console.error(error)
//                 return
//             }

//             //console.log(`statusCode: ${res.statusCode}`)
//             expect(res.statusCode).to.equal(200);
//             console.log(body)
//             done();
//         })
//     });
// });
