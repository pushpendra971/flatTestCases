// var request= require('request');
// var expect = require('chai').expect;
// const baseurl= "http://192.168.5.123:8989/pushpendra/flat/flat?floorNo=1&flatType=3-BHK";

// console.log("******************************END_TO_END_GET_TEST******************************");
// describe('flat data:',function(){
//    it('get flats',function(done){
//        request.get({uri:baseurl},
//            function(err,response,body){
//                expect(response.statusCode).to.equal(200);
//                console.log(body);
//                done();
//            })
//    });
// })