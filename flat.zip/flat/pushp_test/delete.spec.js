var DELETE = require('/home/force-laptop-11/flat/src/lambda/flat/DELETE');
const logger = Object.assign({}, console);
var expect = require('chai').expect;
var assert = require('chai').assert;

console.log("****************************DELETE_API******************************************");
describe('DELETE FLAT API test-cases', function () {


    describe('DELETE (failed) flat via flat Id and active check ', function () {
        var deleteJSON = {
            "httpMethod": "DELETE",
            "body": {
                "active": "true",
            }
        };
        it("active should be string", function (done) {
               assert.typeOf(deleteJSON.body.active,"string");
                done();
        });
        it("active should be one of the allowed values:true||false", function (done) {
            expect(deleteJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatId should be required.", function (done) {
            closure_separate_function_execution(deleteJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();

            });

        });  
    });

    describe('delete (failed) flat via invalid flat Id and active check ', function () {
        var deleteJSON = {
            "httpMethod": "DELETE",
            "body": {
                "active": "false",
                "flatId": "e45",
            }
        };
        it("active or flatId does not exit", function (done) {
            closure_separate_function_execution(deleteJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();

            });

        });
    });
    describe('delete (failed) flat via invalid flat Id and active check ', function () {
        var deleteJSON = {
            "httpMethod": "DELETE",
            "body": {
                "active": "true",
                "flatId": "a410",
                "buildingName": "a",
                "flatStatus":"sold"
            }
        };
        it("should not have additional properties...only active and flatId required.", function (done) {
            closure_separate_function_execution(deleteJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();

            });

        });
    });

    describe('delete flat via valid flat Id and active and valid buildingName ', function () {
        var deleteJSON = {
            "httpMethod": "DELETE",
            "body": {
                "active": "true",
                "flatId": "string",
                "buildingName":"d"

            }
        };

        it("active should be one of the allowed values:true||false", function (done) {
            expect(deleteJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });

        it('fields should be string', function (done) {
            assert.typeOf(deleteJSON.body.flatId, 'string');
            assert.typeOf(deleteJSON.body.active, 'string');
            assert.typeOf(deleteJSON.body.buildingName, 'string');
            done();
        });

        it("flat is deleted successfully.", function (done) {
            closure_separate_function_execution(deleteJSON, function (err, data) {
                if(data.statusCode==200){
                    expect(data.statusCode).to.equal(200);
                   // logger.log(JSON.stringify(data, null, 6));
                    done();
                }else{
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data, null, 6));
                done(new Error(data.body));}
            });
        });
    });
});

function closure_separate_function_execution(deleteJSON, cb) {
    console['log'] = function () { return {} };
    DELETE.execute(deleteJSON.body, function (error, data) {
        if (error) {
            //return error;
            cb(error)
        }
        else {
            console['log'] = logger.log;
            //logger.log(data);
            cb(null, data);
        }
    });
};