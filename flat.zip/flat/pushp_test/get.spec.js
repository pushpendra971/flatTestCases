var GET = require('/home/force-laptop-11/flat/src/lambda/flat/GET');

const logger = Object.assign({}, console);
var expect = require('chai').expect;
var assert = require('chai').assert;

console.log("****************************GET_API******************************************");
describe('GET FLAT API test-cases', function () {
    describe('GET flat via features check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "features": "Gym"
            }
        };

        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                //logger.log(JSON.stringify(data, null, 6));
                expect(data.statusCode).to.equal(200);
                done();
            });
        });
        it('feature_name should be string type', function () {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.features, "string");
        });

        it('check valid response datatype', function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (err) {
                    expect(err.statusCode).to.equal(400);
                    logger.log(err);
                    done(err);
                }
                else {
                    //logger.log(JSON.stringify(data, null, 6));
                    expect(data.statusCode).to.equal(200);
                    get_valid_response_check(data, function () {
                        done();
                    })
                }
            });
        })
    });

    describe('GET flat via active check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "active": "true"
            }
        };
        it('should be string type', function () {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.active, "string");
        });

        it("should be allowed values:true||false", function (done) {
            expect(getJSON_valid_get_all_flat.queryStringParameters.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {

                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    //logger.log(JSON.stringify(data, null, 6));
                    get_valid_response_check(data, function () {
                        done();
                    })
                } else {
                    expect(data.statusCode).to.equal(400);
                    //logger.log(JSON.stringify(data, null, 6));
                    done(new Error(data.body));
                }

            });
        });

    });
    describe('GET flat via floorNo check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "floorNo": "2"
            }
        };
        it('should be string type', function () {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.floorNo, "string");
        });

        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {

                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    // logger.log(JSON.stringify(data, null, 6));
                    get_valid_response_check(data, function () {
                        done();
                    })

                } else {
                    expect(data.statusCode).to.equal(400);
                    //logger.log(JSON.stringify(data, null, 6));
                    done(new Error(data.body));
                }

            });

        });


    });
    describe('GET flat via multiple floorNo check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "floorNo": "2,3"
            }
        };
        it('should be string type', function () {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.floorNo, "string");
        });

        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {

                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    // logger.log(JSON.stringify(data, null, 6));
                    get_valid_response_check(data, function () {
                        done();
                    })

                } else {
                    expect(data.statusCode).to.equal(400);
                    //logger.log(JSON.stringify(data, null, 6));
                    done(new Error(data.body));
                }

            });

        });


    });


    describe('GET flat via flat_type check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "flatType": "2-BHK"
            }
        };
        it('flatType should be string type', function () {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.flatType, "string");
        });

        it("should be allowed values: 1-BHK || 2-BHK || 3-BHK", function (done) {
            expect(getJSON_valid_get_all_flat.queryStringParameters.flatType).to.be.oneOf(['1-BHK', '2-BHK', '3-BHK']);
            done();
        });
        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    // logger.log(JSON.stringify(data, null, 6));
                    get_valid_response_check(data, function () {
                        done();
                    })
                } else {
                    expect(data.statusCode).to.equal(400);
                    //logger.log(JSON.stringify(data, null, 6));
                    done(new Error(data.body));
                }

            });

        });

    });


    describe('GET flat(failed) via invalid flat_type check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "flatType": "2BHK"
            }
        };

        it("flat_type should be allowed values: 1-BHK || 2-BHK || 3-BHK", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                // logger.log(JSON.stringify(data, null, 6));
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });

    describe('GET flat via flatStatus check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "flatStatus": "sold"
            }
        };

        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    // logger.log(JSON.stringify(data, null, 6));
                    get_valid_response_check(data, function () {
                        done();
                    })
                } else {
                    expect(data.statusCode).to.equal(400);
                    //logger.log(JSON.stringify(data, null, 6));
                    done(new Error(data.body));
                }
            });

        })
        it('should be string type', function () {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.flatStatus, "string");
        });
        it("flatStatus should be one of allowed values: available || reserved || sold ", function (done) {
            expect(getJSON_valid_get_all_flat.queryStringParameters.flatStatus).to.be.oneOf(['available', 'reserved', 'sold']);
            done();
        });
    });
    describe('GET flat via pagination check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "lastEvaluatedKeyactive": "true",
                "lastEvaluatedKeyflatId": "a410",
                "lastEvaluatedKeytotalPrice": "75000"
            }
        };

        it("should return flat data", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                //  logger.log(JSON.stringify(data, null, 6));
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    get_valid_response_check(data, function () {
                        done();
                    })
                } else {
                    expect(data.statusCode).to.equal(400);
                    //logger.log(JSON.stringify(data, null, 6));
                    done(new Error(data.body));
                }

            });

        })
    });
    describe('GET flat via priceSort check ', function () {
        var getJSON_valid_get_all_flat = {
            "httpMethod": "GET",
            "queryStringParameters": {
                "priceSort": "true"
            }
        };

        it("should return flat data in sorted order by price", function (done) {
            closure_separate_function_execution(getJSON_valid_get_all_flat, function (err, data) {
                //  logger.log(JSON.stringify(data, null, 6));
                get_valid_response_check(data, function () {
                    done();
                })
            });

        })
        it('should be string type : true || false', function () {
            assert.typeOf(getJSON_valid_get_all_flat.queryStringParameters.priceSort, "string");
        });
    });
});



function closure_separate_function_execution(getJSON_valid_get_all_flat, cb) {
    console['log'] = function () { return {} };
    GET.execute(getJSON_valid_get_all_flat.queryStringParameters, function (error, data) {
        if (error) {
            cb(error);
        }
        else {
            console['log'] = logger.log;
            cb(null, data);
        }
    })
}

function get_valid_response_check(data, call) {
    var item = JSON.parse(data.body);
    var len = item.data.length;
    // logger.log(len);
    for (i = 0; i < len; i++) {
        assert.typeOf(item.data[i].active, "string");
        assert.typeOf(item.data[i].flatId, "string");
        assert.typeOf(item.data[i].floorNo, "number");
        assert.typeOf(item.data[i].flatType, "string");
        assert.typeOf(item.data[i].flatStatus, "string");
        assert.typeOf(item.data[i].features, "array");
        assert.typeOf(item.data[i].pricePerSquare, "number");
        assert.typeOf(item.data[i].buildingName, "string");
        assert.typeOf(item.data[i].area, "number");
        assert.typeOf(item.data[i].totalPrice, "number");
    }
    call();
}