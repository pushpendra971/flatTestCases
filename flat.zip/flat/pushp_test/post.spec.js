


var POST = require('/home/force-laptop-11/flat/src/lambda/flat/POST');
const logger = Object.assign({}, console);
var expect = require('chai').expect;
var assert = require('chai').assert;
console.log("****************************POST_API******************************************");
describe('POST FLAT API test-cases', function () {

    describe('POST (failed) flat via  active check ', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {

                "active": "true"
            }
        };
        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be required.", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data,null,6));
                done();
            });
        });

    });

    describe('POST (failed) flat via flat Id and active check ', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "a45",
                "active": "true"
            }
        };

        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be string", function (done) {
            assert.typeOf(postJSON.body.flatId, "string");
            done();
        });
        it("buildingName should be required return 400", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data,null,6));
                done();
            });
        });

    });

    describe('POST (failed) flat via flat Id and active and buildingName check ', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "a45",
                "active": "true",
                "buildingName": "a"
            }
        };

        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be string", function (done) {
            assert.typeOf(postJSON.body.flatId, "string");
            done();
        });
        it("buildingName should be string", function (done) {
            assert.typeOf(postJSON.body.buildingName, "string");
            done();
        });

        it("floorNo should be required: return 400", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data,null,6));
                done();
            });
        });
    });

    describe('POST (failed) flat via flat Id,active,buildingName and floorNo check ', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "a45",
                "active": "true",
                "buildingName": "a",
                "floorNo": 3
            }
        };
        it("active should be string.", function (done) {
                assert.typeOf(postJSON.body.active, "string");
                done();
        });
        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be string", function (done) {
            assert.typeOf(postJSON.body.flatId, "string");
            done();
        });
        it("buildingName should be string", function (done) {
            assert.typeOf(postJSON.body.buildingName, "string");
            done();
        });
        it("floorNO should be number", function (done) {
            assert.typeOf(postJSON.body.floorNo, "number");
            done();
        });
        it("floorNo should be one of the allowed values:0||1||2||3||4", function (done) {
            expect(postJSON.body.floorNo).to.be.oneOf([0, 1, 2, 3, 4]);
            done();
        });

        it("flatType should be required return 400", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data,null,6));
                done();
            });
        });
    });

    describe('POST (failed) flat via flat Id,active,buildingName ,floorNo and flatType check ', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "a45",
                "active": "true",
                "buildingName": "a",
                "floorNo": 3,
                "flatType": "3-BHK"

            }
        };

        it("active should be string.", function (done) {
                assert.typeOf(postJSON.body.active, "string");
                done();
        });
        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
     
        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be string", function (done) {
            assert.typeOf(postJSON.body.flatId, "string");
            done();
        });
        it("buildingName should be string", function (done) {
            assert.typeOf(postJSON.body.buildingName, "string");
            done();
        });
        it("floorNO should be number", function (done) {
            assert.typeOf(postJSON.body.floorNo, "number");
            done();
        });
        it("floorNo should be one of the allowed values:0||1||2||3||4", function (done) {
            expect(postJSON.body.floorNo).to.be.oneOf([0, 1, 2, 3, 4]);
            done();
        });
        it("flatType should be string", function (done) {
            assert.typeOf(postJSON.body.flatType, "string");
            done();
        });
        it("flatType should be one of the allowed values:1-BHK||2-BHK||3-BHK", function (done) {
            expect(postJSON.body.flatType).to.be.oneOf(["1-BHK", "2-BHK", "3-BHK"]);
            done();
        });
        it("flatStatus should be required return 400", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data,null,6));
                done();
            });
        });

    });

    describe('POST (failed) flat via flat Id,active,buildingName ,floorNo and flatType and flatStatus check ', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "a45",
                "active": "true",
                "buildingName": "a",
                "floorNo": 3,
                "flatType": "3-BHK",
                "flatStatus": "sold"

            }
        };

        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be string", function (done) {
            assert.typeOf(postJSON.body.flatId, "string");
            done();
        });
        it("buildingName should be string", function (done) {
            assert.typeOf(postJSON.body.buildingName, "string");
            done();
        });
        it("floorNO should be number", function (done) {
            assert.typeOf(postJSON.body.floorNo, "number");
            done();
        });
        it("floorNo should be one of the allowed values:0||1||2||3||4", function (done) {
            expect(postJSON.body.floorNo).to.be.oneOf([0, 1, 2, 3, 4]);
            done();
        });
        it("flatType should be string", function (done) {
            assert.typeOf(postJSON.body.flatType, "string");
            done();
        });
        it("flatType should be one of the allowed values:1-BHK||2-BHK||3-BHK", function (done) {
            expect(postJSON.body.flatType).to.be.oneOf(["1-BHK", "2-BHK", "3-BHK"]);
            done();
        });
        it("flatStatus should be string", function (done) {
            assert.typeOf(postJSON.body.flatStatus, "string");
            done();
        });
        it("flatStatus should be one of the allowed values: available||reserved||sold", function (done) {
            expect(postJSON.body.flatStatus).to.be.oneOf(["available", "reserved", "sold"]);
            done();
        })
        it("features should be required return 400", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data,null,6));
                done();
            });
        });

    });

    describe('POST (failed) flat via flat Id,active,buildingName ,floorNo,flatType ,flatStatus and features check ', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "a45",
                "active": "true",
                "buildingName": "a",
                "floorNo": 3,
                "flatType": "3-BHK",
                "flatStatus": "sold",
                "features": ["Parking", "gym"]

            }
        };

        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be string", function (done) {
            assert.typeOf(postJSON.body.flatId, "string");
            done();
        });
        it("buildingName should be string", function (done) {
            assert.typeOf(postJSON.body.buildingName, "string");
            done();
        });
        it("floorNO should be number", function (done) {
            assert.typeOf(postJSON.body.floorNo, "number");
            done();
        });
        it("floorNo should be one of the allowed values:0||1||2||3||4", function (done) {
            expect(postJSON.body.floorNo).to.be.oneOf([0, 1, 2, 3, 4]);
            done();
        });
        it("flatType should be string", function (done) {
            assert.typeOf(postJSON.body.flatType, "string");
            done();
        });
        it("flatType should be one of the allowed values:1-BHK||2-BHK||3-BHK", function (done) {
            expect(postJSON.body.flatType).to.be.oneOf(["1-BHK", "2-BHK", "3-BHK"]);
            done();
        });
        it("flatStatus should be string", function (done) {
            assert.typeOf(postJSON.body.flatStatus, "string");
            done();
        });
        it("flatStatus should be one of the allowed values: available||reserved||sold", function (done) {
            expect(postJSON.body.flatStatus).to.be.oneOf(["available", "reserved", "sold"]);
            done();
        });

        it("features should be array", function (done) {
            assert.typeOf(postJSON.body.features, "array");
            done();
        });

        it("area should be required return 400", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data,null,6));
                done();
            });
        });
    });

    describe('POST (failed) flat via flat Id,active,buildingName ,floorNo,flatType ,flatStatus and features check and area ', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "a45",
                "active": "true",
                "buildingName": "a",
                "floorNo": 3,
                "flatType": "3-BHK",
                "flatStatus": "sold",
                "features": ["Parking", "gym"],
                "area": 80.00

            }
        };

        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be string", function (done) {
            assert.typeOf(postJSON.body.flatId, "string");
            done();
        });
        it("buildingName should be string", function (done) {
            assert.typeOf(postJSON.body.buildingName, "string");
            done();
        });
        it("floorNO should be number", function (done) {
            assert.typeOf(postJSON.body.floorNo, "number");
            done();
        });
        it("floorNo should be one of the allowed values:0||1||2||3||4", function (done) {
            expect(postJSON.body.floorNo).to.be.oneOf([0, 1, 2, 3, 4]);
            done();
        });
        it("flatType should be string", function (done) {
            assert.typeOf(postJSON.body.flatType, "string");
            done();
        });
        it("flatType should be one of the allowed values:1-BHK||2-BHK||3-BHK", function (done) {
            expect(postJSON.body.flatType).to.be.oneOf(["1-BHK", "2-BHK", "3-BHK"]);
            done();
        });
        it("flatStatus should be string", function (done) {
            assert.typeOf(postJSON.body.flatStatus, "string");
            done();
        });
        it("flatStatus should be one of the allowed values: available||reserved||sold", function (done) {
            expect(postJSON.body.flatStatus).to.be.oneOf(["available", "reserved", "sold"]);
            done();
        });

        it("features should be array", function (done) {
            assert.typeOf(postJSON.body.features, "array");
            done();
        });
        it("area should be number", function (done) {
            assert.typeOf(postJSON.body.area, "number");
            done();
        });
        it("pricePerSquare should be required return 400", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data,null,6));
                done();
            });
        });
    });

    describe('POST (failed) flat via flat Id,active,buildingName ,floorNo,flatType ,flatStatus ,features,area and pricePerSquare ', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "a45",
                "active": "true",
                "buildingName": "a",
                "floorNo": 3,
                "flatType": "3-BHK",
                "flatStatus": "sold",
                "features": ["Parking", "gym"],
                "area": 80.00,
                "pricePerSquare": 1000.00

            }
        };
        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be string", function (done) {
            assert.typeOf(postJSON.body.flatId, "string");
            done();
        });
        it("buildingName should be string", function (done) {
            assert.typeOf(postJSON.body.buildingName, "string");
            done();
        });
        it("floorNO should be number", function (done) {
            assert.typeOf(postJSON.body.floorNo, "number");
            done();
        });
        it("floorNo should be one of the allowed values:0||1||2||3||4", function (done) {
            expect(postJSON.body.floorNo).to.be.oneOf([0, 1, 2, 3, 4]);
            done();
        });
        it("flatType should be string", function (done) {
            assert.typeOf(postJSON.body.flatType, "string");
            done();
        });
        it("flatType should be one of the allowed values:1-BHK||2-BHK||3-BHK", function (done) {
            expect(postJSON.body.flatType).to.be.oneOf(["1-BHK", "2-BHK", "3-BHK"]);
            done();
        });
        it("flatStatus should be string", function (done) {
            assert.typeOf(postJSON.body.flatStatus, "string");
            done();
        });
        it("flatStatus should be one of the allowed values: available||reserved||sold", function (done) {
            expect(postJSON.body.flatStatus).to.be.oneOf(["available", "reserved", "sold"]);
            done();
        });

        it("features should be array", function (done) {
            assert.typeOf(postJSON.body.features, "array");
            done();
        });
        it("area should be number", function (done) {
            assert.typeOf(postJSON.body.area, "number");
            done();
        });
        it("pricePerSquare should be number", function (done) {
            assert.typeOf(postJSON.body.pricePerSquare, "number");
            done();
        });

        it("totalPrice should be required return 400", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data,null,6));
                done();
            });
        });
    });

    describe('POST flat via flat Id,active,buildingName ,floorNo,flatType ,flatStatus ,features,area ,pricePerSquare and totalPrice check', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "string",
                "active": "true",
                "buildingName": "d",
                "floorNo": 4,
                "flatType": "3-BHK",
                "flatStatus": "sold",
                "features": ["Parking", "Gym"],
                "area": 80.00,
                "pricePerSquare": 1000.00,
                "totalPrice": 80000.00
            }
        };

        it("active should be string.", function (done) {
            assert.typeOf(postJSON.body.active, "string");
            done();

        });

        it("active should be one of the allowed values:true||false", function (done) {
            expect(postJSON.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it("flatid should be string", function (done) {
            assert.typeOf(postJSON.body.flatId, "string");
            done();
        });
        it("buildingName should be string", function (done) {
            assert.typeOf(postJSON.body.buildingName, "string");
            done();
        });
        it("floorNO should be number", function (done) {
            assert.typeOf(postJSON.body.floorNo, "number");
            done();
        });
        it("floorNo should be one of the allowed values:0||1||2||3||4", function (done) {
            expect(postJSON.body.floorNo).to.be.oneOf([0, 1, 2, 3, 4]);
            done();
        });
        it("flatType should be string", function (done) {
            assert.typeOf(postJSON.body.flatType, "string");
            done();
        });
        it("flatType should be one of the allowed values:1-BHK||2-BHK||3-BHK", function (done) {
            expect(postJSON.body.flatType).to.be.oneOf(["1-BHK", "2-BHK", "3-BHK"]);
            done();
        });
        it("flatStatus should be string", function (done) {
            assert.typeOf(postJSON.body.flatStatus, "string");
            done();
        });
        it("flatStatus should be one of the allowed values: available||reserved||sold", function (done) {
            expect(postJSON.body.flatStatus).to.be.oneOf(["available", "reserved", "sold"]);
            done();
        });

        it("features should be array", function (done) {
            assert.typeOf(postJSON.body.features, "array");
            done();
        });
        it("area should be number", function (done) {
            assert.typeOf(postJSON.body.area, "number");
            done();
        });
        it("pricePerSquare should be number", function (done) {
            assert.typeOf(postJSON.body.pricePerSquare, "number");
            done();
        });
        it("totalPrice should be number", function (done) {
            assert.typeOf(postJSON.body.totalPrice, "number");
            done();
        });

        it("Post new flat :", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                if(data.statusCode==200){
                    expect(data.statusCode).to.equal(200);
                   // logger.log(JSON.stringify(data, null, 6));
                    done();
                }else{
                expect(data.statusCode).to.equal(400);
                //logger.log(JSON.stringify(data, null, 6));
                done(new Error(data.body));}
            });
        });
    });

    describe('POST(failed) flat via duplicate flat_id check', function () {
        var postJSON = {
            "httpMethod": "POST",
            "body": {
                "flatId": "a45",
                "active": "true",
                "buildingName": "a",
                "floorNo": 3,
                "flatType": "3-BHK",
                "flatStatus": "sold",
                "features": ["Parking", "Gym"],
                "area": 80.00,
                "pricePerSquare": 1000.00,
                "totalPrice": 80000.00
            }
        };
        it("flatID already exit.", function (done) {
            closure_separate_function_execution(postJSON, function (err, data) {
                expect(data.statusCode).to.equal(400);
                // logger.log(JSON.stringify(data,null,6));
                done();
            });
        });
    });
});


function closure_separate_function_execution(postJSON, cb) {
    console['log'] = function () { return {} };
    POST.execute(postJSON.body, function (error, data) {
        if (error) {
            cb(error)
        }
        else {
            console['log'] = logger.log;
            cb(null, data);
        }
    });
};