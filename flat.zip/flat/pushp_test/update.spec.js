// var UPDATE = require('/home/force-laptop-11/flat/src/lambda/flat/UPDATE');
// const logger = Object.assign({}, console);
// var expect = require('chai').expect;
// var assert = require('chai').assert;

// console.log("****************************UPDATE_API******************************************");
// describe('UPDATE FLAT API test-cases', function () {

//     describe('UPDATE (failed) flat via flat Id and active check ', function () {
//         var updateJSON_valid_update_all_flat = {
//             "httpMethod": "UPDATE",
//             "body": {
//                 "flatId": "a45",
//                 "active": "true"
//             }
//         };
//         it("should be flatStatus required return 400", function (done) {
//             closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
//                 expect(data.statusCode).to.equal(400);
//                // logger.log(JSON.stringify(data,null,6));
//                 done();
//             });
//         });
//     });

//     describe('UPDATE (failed) flat via active and flatStatus check ', function () {
//         var updateJSON_valid_update_all_flat = {
//             "httpMethod": "UPDATE",
//             "body": {
//                 "flatStatus": "sold",
//                 "active": "true"
//             }
//         };

//         it("should be flatId required return 400", function (done) {
//             closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
//                 expect(data.statusCode).to.equal(400);
//                // logger.log(JSON.stringify(data,null,6));
//                 done();
//             });
//         });
//     });

//     describe('UPDATE (failed) flat via flat Id and flatStatus check ', function () {
//         var updateJSON_valid_update_all_flat = {
//             "httpMethod": "UPDATE",
//             "body": {
//                 "flatStatus": "sold",
//                 "flatId": "a45"
//             }
//         };

//         it("should be active required return 400", function (done) {
//             closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
//                 expect(data.statusCode).to.equal(400);
//                 //logger.log(JSON.stringify(data,null,6));
//                 done();
//             });
//         });
//     });


//     describe('UPDATE (failed) flat via invalid flat Id and active check ', function () {
//         var updateJSON_valid_update_all_flat = {
//             "httpMethod": "UPDATE",
//             "body": {
//                 "flatId": "e45",
//                 "active": "false",
//                 "flatStatus": "sold"
//             }
//         };
//         it("active or flatId does not exit", function (done) {
//             closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
//                 expect(data.statusCode).to.equal(400);
//                // logger.log(JSON.stringify(data,null,6));
//                 done();

//             });

//         });
//         it('should be string', function (done) {
//             assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
//             assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
//             assert.typeOf(updateJSON_valid_update_all_flat.body.flatStatus, 'string');
//             done();
//         });
//     });

//     describe('UPDATE flat via valid flat Id and active and flatStatus check ', function () {
//         var updateJSON_valid_update_all_flat = {
//             "httpMethod": "UPDATE",
//             "body": {
//                 "flatId": "a410",
//                 "active": "true",
//                 "flatStatus": "sold",
//                 "buildingName":"a"
//             }
//         };
//         it("should return updated flat data", function (done) {
//             closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
//                 if (err) {
//                     expect(err.statusCode).to.equal(400);
//                     logger.log(err);
//                     done(err);
//                 }
//                 else {
//                     expect(data.statusCode).to.equal(200);
//                     //logger.log(JSON.stringify(data,null,6));
//                     done();
//                 }
//             });
//         });
//         it('check valid response datatype',function(done){
//             closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
//                 if (err) {
//                     expect(err.statusCode).to.equal(400);
//                     logger.log(err);
//                     done(err);
//                 }
//                 else {
//                     expect(data.statusCode).to.equal(200);
//                     var item = JSON.parse(data.body);
//                    assert.typeOf(item.data.active,"string");
//                    assert.typeOf(item.data.flatId,"string");
//                    assert.typeOf(item.data.floorNo,"number");
//                    assert.typeOf(item.data.flatType,"string");
//                    assert.typeOf(item.data.flatStatus,"string");
//                    assert.typeOf(item.data.features,"array");
//                    assert.typeOf(item.data.pricePerSquare,"number");
//                    assert.typeOf(item.data.buildingName,"string");
//                    assert.typeOf(item.data.area,"number");
//                    assert.typeOf(item.data.totalPrice,"number");
//                    done();
//                 }
//                 // done();
//             });
//         })
//         it('fields should be string', function (done) {
//             assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
//             assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
//             assert.typeOf(updateJSON_valid_update_all_flat.body.flatStatus, 'string');
//             done();
//         });

//         it("active should be one of the allowed values:true||false", function (done) {
//             expect(updateJSON_valid_update_all_flat.body.active).to.be.oneOf(['true', 'false']);
//             done();
//         });

//         it("flatStatus should be one of the allowed values: available || reserved || sold ", function (done) {
//             expect(updateJSON_valid_update_all_flat.body.flatStatus).to.be.oneOf(['available', 'reserved', 'sold']);
//             done();
//         });
//     });
// });

// function closure_separate_function_execution(getJSON_valid_get_all_flat, cb) {
//     console['log'] = function () { return {} };
//     UPDATE.execute(getJSON_valid_get_all_flat.body, {}, function (error, data) {
//         if (error) {
//             //return error;
//             cb(error)
//         }
//         else {
//             console['log'] = logger.log;
//             cb(null, data);
//         }
//     });
// };





/**mukesh update test file */


var UPDATE = require('../src/lambda/flat/UPDATE');
const logger = Object.assign({}, console);
var expect = require('chai').expect;
var assert = require('chai').assert;
console.log("*********************************UPDATE-API-TESTING*********************************");
describe('UPDATE test-cases', function () {
    describe('UPDATE flat via flat Id check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43"
            }
        };
        it('should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it("active should be required", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('UPDATE flat via flat Id and active check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43",
                "active": "true"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(updateJSON_valid_update_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
            done();
        });
        it("buildingName should be required", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('UPDATE flat via flat Id and active check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43",
                "active": "true",
                "buildingName": "h"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(updateJSON_valid_update_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.buildingName, 'string');
            done();
        });
        it("flatStatus should be required", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('UPDATE flat via flat Id and active check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "h43",
                "active": "true",
                "buildingName": "h",
                "flatStatus": "sold"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(updateJSON_valid_update_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatStatus should be one of allowed values: available/sold/reserved', function (done) {
            expect(updateJSON_valid_update_all_flat.body.flatStatus).to.be.oneOf(['available', 'sold', 'reserved']);
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatStatus, 'string');
            done();
        });
        it("flat doesn't exits", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                expect(data.statusCode).to.equal(400);
                done();
            });
        });
    });
    describe('UPDATE flat via flat Id,active.buiildingName and flatStatus check ', function () {
        var updateJSON_valid_update_all_flat = {
            "httpMethod": "UPDATE",
            "body": {
                "flatId": "string",
                "active": "true",
                "buildingName": "d",
                "flatStatus": "sold"
            }
        };
        it('active should be one of allowed values: true/false', function (done) {
            expect(updateJSON_valid_update_all_flat.body.active).to.be.oneOf(['true', 'false']);
            done();
        });
        it('flatId should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatId, 'string');
            done();
        });
        it('active should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.active, 'string');
            done();
        });
        it('buildingName should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.buildingName, 'string');
            done();
        });
        it('flatStatus should be one of allowed values: available/sold/reserved', function (done) {
            expect(updateJSON_valid_update_all_flat.body.flatStatus).to.be.oneOf(['available', 'sold', 'reserved']);
            done();
        });
        it('flatStatus should be string', function (done) {
            assert.typeOf(updateJSON_valid_update_all_flat.body.flatStatus, 'string');
            done();
        });
        it("New flat updated successfully", function (done) {
            closure_separate_function_execution(updateJSON_valid_update_all_flat, function (err, data) {
                if (data.statusCode == 200) {
                    expect(data.statusCode).to.equal(200);
                    done();
                }
                else {
                    expect(data.statusCode).to.equal(400);
                    done(new Error(data.body));
                }
            });
        });
    });
});

function closure_separate_function_execution(getJSON_valid_get_all_flat, cb) {
    console['log'] = function () { return {} };
    UPDATE.execute(getJSON_valid_get_all_flat.body, {}, function (error, data) {
        if (error) {
            //return error;
            cb(error)
        }
        else {
            console['log'] = logger.log;
            // logger.log(data);
            cb(null, data);
        }
    });
};





