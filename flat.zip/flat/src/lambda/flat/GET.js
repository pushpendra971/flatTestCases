//******************************************************************************************************************************************* /

///// ...................................... start default setup ............................................////
let mode, docClient, S3;
const AWS = require('aws-sdk');
const response = require('./lib/response.js');
const database = require('./lib/database.js');
// console.log(process.env.AWS_REGION);
if (process.env.AWS_REGION == "local") {
	mode = "offline";
	docClient = require('../../../offline/dynamodb').docClient;
} else {
	mode = "online";
	docClient = new AWS.DynamoDB.DocumentClient({});
}
///// ...................................... end default setup ............................................////

// modules defined here
const Ajv = require('ajv');
const setupAsync = require('ajv-async');
const ajv = setupAsync(new Ajv);

const getSchema = {
	"$async": true,
	"type": "object",
	"additionalProperties": false,

	"properties":
	{
		"active": {
			"type": "string",
			"enum": [
				"true",
				"false"
			]
		},
		"flatId": {
			"type": "string"
		},
		"buildingName": {
			"type": "number",
		},
		"floorNo": {
			"type": "string",

		},
		"flatType": {
			"type": "string",
			"enum": [
				"1-BHK",
				"2-BHK",
				"3-BHK"
			]
		},
		"flatStatus": {
			"type": "string",
			"enum": [
				"available",
				"reserved",
				"sold"
			]
		},
		"priceSort": {
			"type": "string"
		},
		"features": {
			"type": "string",
		},
		"lastEvaluatedKeyflatId": {
			"type": "string"
		},
		"lastEvaluatedKeytotalPrice": {
			"type": "string"
		},
		"lastEvaluatedKeyactive": {
			"type": "string"
		}
	}
};
const validate = ajv.compile(getSchema);

module.exports = { execute };

/**
 * This is the Promise caller which will call each and every function based
 * @param  {[type]}   data     [content to manipulate the data]
 * @param  {Function} callback [need to send response with]
 * @return {[type]}            [description]
 */


function execute(data, callback) {
	validate_all(validate, data)
		.then(function (result) {
			return getFlats(result);
		})
		.then(function (result) {
			response({ code: 200, body: result }, callback);
		})
		.catch(function (err) {
			response({ code: 400, err: { err } }, callback);
		})
}

/**
 * validate the data to the categories
 * @param  {[type]} data [description]
 * @return {[type]}      [description]
 */
function validate_all(validate, data) {
	return new Promise((resolve, reject) => {
		validate(data).then(function (res) {
			console.log(res);
			resolve(res);
		}).catch(function (err) {
			console.log(JSON.stringify(err, null, 6));
			reject(err.errors[0].dataPath + " " + err.errors[0].message);
		})
	})
}
var offset = 10;
function getFlats(data) {
	console.log(database);
	var params = {
		TableName: database.Table[1].TableName,
		IndexName: database.Table[1].IndexName
	};
	if (data.active) {
		params["KeyConditionExpression"] = "#active = :active";
		params["ExpressionAttributeValues"] = { ":active": data.active };
		params["ExpressionAttributeNames"] = { "#active": "active" };
		if (data.floorNo) {
			if (data.floorNo.length == 1) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floorNo IN (:floorNo)";
				params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo);
				params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
			}
			if (data.floorNo.length == 3) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floorNo IN (:floorNo,:florNo)";
				params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo.substring(0, 1));
				params["ExpressionAttributeValues"][":florNo"] = parseInt(data.floorNo.substring(2, 3));
				params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
			}
			if (data.floorNo.length == 5) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floorNo IN (:floorNo,:florNo,:flrNo)";
				params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo.substring(0, 1));
				params["ExpressionAttributeValues"][":florNo"] = parseInt(data.floorNo.substring(2, 3));
				params["ExpressionAttributeValues"][":flrNo"] = parseInt(data.floorNo.substring(4, 5));
				params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
			}
			if (data.floorNo.length == 7) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floorNo IN (:floorNo,:florNo,:flrNo,:flNo)";
				params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo.substring(0, 1));
				params["ExpressionAttributeValues"][":florNo"] = parseInt(data.floorNo.substring(2, 3));
				params["ExpressionAttributeValues"][":flrNo"] = parseInt(data.floorNo.substring(4, 5));
				params["ExpressionAttributeValues"][":flNo"] = parseInt(data.floorNo.substring(6, 7));
				params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
			}
			if (data.floorNo.length == 9) {
				if (params['FilterExpression'] == undefined) {
					params['FilterExpression'] = "";
				}
				params["FilterExpression"] += "#floorNo IN (:floorNo,:florNo,:flrNo,:flNo,:fNo)";
				params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo.substring(0, 1));
				params["ExpressionAttributeValues"][":florNo"] = parseInt(data.floorNo.substring(2, 3));
				params["ExpressionAttributeValues"][":flrNo"] = parseInt(data.floorNo.substring(4, 5));
				params["ExpressionAttributeValues"][":flNo"] = parseInt(data.floorNo.substring(6, 7));
				params["ExpressionAttributeValues"][":fNo"] = parseInt(data.floorNo.substring(8, 9));
				params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
			}
		}
		if (data.flatType) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			} else {
				params['FilterExpression'] += " and ";
			}
			params["FilterExpression"] += " #flatType =(:flatType)";
			params["ExpressionAttributeValues"][":flatType"] = data.flatType;
			params["ExpressionAttributeNames"]["#flatType"] = "flatType";
		}
		if (data.flatStatus) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			}
			else {
				params['FilterExpression'] += " and ";
			}
			params["FilterExpression"] += " #flatStatus =(:flatStatus)";
			params["ExpressionAttributeValues"][":flatStatus"] = data.flatStatus;
			params["ExpressionAttributeNames"]["#flatStatus"] = "flatStatus";
		}
		if (data.features) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			}
			else {
				params['FilterExpression'] += " and ";
			}
			params["FilterExpression"] += "contains(#features,:features)";
			params["ExpressionAttributeValues"][":features"] = data.features;
			params["ExpressionAttributeNames"]["#features"] = "features";
		}
		if (data.priceSort == "true") {
			params['ScanIndexForward'] = true;
		} else {
			params['ScanIndexForward'] = false;
		}
		return new Promise((resolve, reject) => {
			params['Limit'] = offset;
			if (data.lastEvaluatedKeyflatId && data.lastEvaluatedKeyactive && data.lastEvaluatedKeytotalPrice) {
				try {
					params['ExclusiveStartKey'] = {
						active: data.lastEvaluatedKeyactive,
						flatId: data.lastEvaluatedKeyflatId,
						totalPrice: parseFloat(data.lastEvaluatedKeytotalPrice)
					};
				} catch (error) {
					reject("Invalid last evaluated keys");
					return;
				}
			}
			console.log("get_data", params);
			docClient.query(params, function (err, data) {
				if (err) {
					reject(err);
				} else {
					console.log(data);
					var container = {};
					container['page'] = data.LastEvaluatedKey;
					container['data'] = data.Items;
					resolve(container);
				}
			});
		})
	} else {
		//scan
		if (data.floorNo || data.flatType || data.features || data.flatStatus || (data.lastEvaluatedKeyflatId && data.lastEvaluatedKeyactive && data.lastEvaluatedKeytotalPrice)) {
			if (data.floorNo) {
				if (data.floorNo.length == 1) {
					console.log(data.floorNo.length);
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floorNo IN (:floorNo)";
					params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo);
					params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
				}
				if (data.floorNo.length == 3) {
					console.log(data.floorNo.length);
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floorNo IN (:floorNo,:florNo)";
					params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo.substring(0, 1));
					params["ExpressionAttributeValues"][":florNo"] = parseInt(data.floorNo.substring(2, 3));
					params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
				}
				if (data.floorNo.length == 5) {
					console.log(data.floorNo.length);
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floorNo IN (:floorNo,:florNo,:flrNo)";
					params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo.substring(0, 1));
					params["ExpressionAttributeValues"][":florNo"] = parseInt(data.floorNo.substring(2, 3));
					params["ExpressionAttributeValues"][":flrNo"] = parseInt(data.floorNo.substring(4, 5));
					params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
				}
				if (data.floorNo.length == 7) {
					//console.log(data.floorNo.length);
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floorNo IN (:floorNo,:florNo,:flrNo,:flNo)";
					params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo.substring(0, 1));
					params["ExpressionAttributeValues"][":florNo"] = parseInt(data.floorNo.substring(2, 3));
					params["ExpressionAttributeValues"][":flrNo"] = parseInt(data.floorNo.substring(4, 5));
					params["ExpressionAttributeValues"][":flNo"] = parseInt(data.floorNo.substring(6, 7));
					params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
				}
				if (data.floorNo.length == 9) {
					//console.log(data.floorNo.length);
					if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
						params['FilterExpression'] = "";
						params['ExpressionAttributeValues'] = {};
						params['ExpressionAttributeNames'] = {};
					}
					params["FilterExpression"] += "#floorNo IN (:floorNo,:florNo,:flrNo,:flNo,:fNo)";
					params["ExpressionAttributeValues"][":floorNo"] = parseInt(data.floorNo.substring(0, 1));
					params["ExpressionAttributeValues"][":florNo"] = parseInt(data.floorNo.substring(2, 3));
					params["ExpressionAttributeValues"][":flrNo"] = parseInt(data.floorNo.substring(4, 5));
					params["ExpressionAttributeValues"][":flNo"] = parseInt(data.floorNo.substring(6, 7));
					params["ExpressionAttributeValues"][":fNo"] = parseInt(data.floorNo.substring(8, 9));
					params["ExpressionAttributeNames"]["#floorNo"] = "floorNo";
				}
			}
			if (data.flatType) {
				if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
					params['FilterExpression'] = "";
					params['ExpressionAttributeValues'] = {};
					params['ExpressionAttributeNames'] = {};
				} else {
					params['FilterExpression'] += " and ";
				}
				params['FilterExpression'] += "#flatType IN (:flatType) "
				params['ExpressionAttributeValues'][":flatType"] = data.flatType;
				params['ExpressionAttributeNames']["#flatType"] = "flatType";
			}
			if (data.features) {
				if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
					params['FilterExpression'] = "";
					params['ExpressionAttributeValues'] = {};
					params['ExpressionAttributeNames'] = {};
				} else {
					params['FilterExpression'] += " and ";
				}
				params['FilterExpression'] += "contains(#features,:features)"
				params['ExpressionAttributeNames']["#features"] = "features";
				params['ExpressionAttributeValues'][":features"] = data.features;
			}
			if (data.flatStatus) {
				if ((params['FilterExpression'] || params['ExpressionAttributeValues'] || params['ExpressionAttributeNames']) == undefined) {
					params['FilterExpression'] = "";
					params['ExpressionAttributeValues'] = {};
					params['ExpressionAttributeNames'] = {};
				} else {
					params['FilterExpression'] += " and ";
				}
				params['FilterExpression'] += "#flatStatus IN (:flatStatus) "
				params['ExpressionAttributeValues'][":flatStatus"] = data.flatStatus;
				params['ExpressionAttributeNames']["#flatStatus"] = "flatStatus";
			}
		}
		return new Promise((resolve, reject) => {
			params['Limit'] = offset;
			if (data.lastEvaluatedKeyflatId && data.lastEvaluatedKeyactive && data.lastEvaluatedKeytotalPrice) {
				try {
					params['ExclusiveStartKey'] = {
						active: data.lastEvaluatedKeyactive,
						flatId: data.lastEvaluatedKeyflatId,
						totalPrice: parseFloat(data.lastEvaluatedKeytotalPrice)
					};
				} catch (error) {
					reject("Invalid last evaluated keys");
					return;
				}
			}
			console.log(params, "scan");
			docClient.scan(params, function (err, data) {
				if (err) {
					reject(err);
				} else {
					console.log(data);
					var container = {};
					container['page'] = data.LastEvaluatedKey;
					container['data'] = data.Items;
					resolve(container);
				}
			});
		})
	}
}