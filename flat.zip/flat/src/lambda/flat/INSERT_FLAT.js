var AWS = require("aws-sdk");
const createdDate = new Date().getTime();
var fs = require('fs');
AWS.config.update({
    region: "localhost",
    endpoint: "http://192.168.5.123:8000"
});
var docClient = new AWS.DynamoDB.DocumentClient();
console.log("Importing flats into DynamoDB. Please wait.");
var allFlats = JSON.parse(fs.readFileSync('FLAT.json', 'utf8'));
allFlats.forEach(function (flat) {
    var params = {
        TableName: "FLAT",
        Item: {
            "active": flat.active,
            "flatId": flat.flatId,
            "buildingName": flat.buildingName,
            "floorNo": flat.floorNo,
            "flatType": flat.flatType,
            "flatStatus": flat.flatStatus,
            "features": flat.features,
            "area": flat.area,
            "pricePerSquare": flat.pricePerSquare,
            "totalPrice": flat.totalPrice,
            "createdAt" :createdDate.toString(),
        }
    };
    docClient.put(params, function (err, data) {
        if (err) {
            console.error("Unable to add flat", flat.flatId, ". Error JSON:",
                JSON.stringify(err, null, 2));
        } else {
            console.log("PutItem succeeded:", flat.flatId);
        }
    });
});