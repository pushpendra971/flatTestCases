

//****************************************************FLAT_API***********************************************************

///// ...................................... start default setup ............................................////
let mode, docClient, S3;
const AWS = require('aws-sdk');
const response = require('./lib/response.js');
var database = require('./lib/database.js');


if (process.env.AWS_REGION == "local") {
	mode = "offline";
	docClient = require('../../../offline/dynamodb').docClient;
	// S3 = require('../../../offline/S3');
} else {
	mode = "online";
	docClient = new AWS.DynamoDB.DocumentClient({});
	// S3 = new AWS.S3();
}
///// ...................................... end default setup ............................................////

//modules defined here

const Ajv = require('ajv');
const setupAsync = require('ajv-async');
const ajv = setupAsync(new Ajv);
const createdDate = new Date().getTime();
console.log(new Date(createdDate));
const PostSchema = {
	"$async": true,
	"type": "object",
	"additionalProperties": false,
	"required": ['active','buildingName',"flatId","floorNo","flatType","flatStatus",
	                        "features","area","pricePerSquare","totalPrice"],
	"properties":
	{
	"active": {
		"type": "string",
		"enum": [
			"true",
			"false",
			"TRUE",
			"FALSE",
			"True",
			"False"
		]
	},
	"flatId": {
		"type": "string",
		"minimum": 3,
		"maximum": 3,
		"example": "a01"
	},
	"buildingName": {
		"type": "string",
	},
	"floorNo": {
		"type": "number",
		"enum": [
			0,
			1,
			2,
			3,
			4
		]
	},
	"flatType": {
		"type": "string",
		"enum": [
			"1-BHK",
			"2-BHK",
			"3-BHK",
			"1-Bhk",
			"2-Bhk",
			"3-Bhk",
			"1-bhk",
			"2-bhk",
			"3-bhk",
			
		]
	},
	"flatStatus": {
		"type": "string",
		"enum": [
			"available",
			"reserved",
			"sold",
			"Available",
			"Reserved",
			"Sold",
			"AVAILABLE",
			"RESERVED",
			"SOLD"
	
		]
	},
	"area": {
		"type": "number"
	},
	"pricePerSquare": {
		"type": "number"
	},
	"totalPrice": {
		"type": "number"
	},
	"features": {
		"type": "array",
	}
}
};

const validate = ajv.compile(PostSchema);


module.exports = { execute };

/**
 * This is the Promise caller which will call each and every function based
 * @param  {[type]}   data     [content to manipulate the data]
 * @param  {Function} callback [need to send response with]
 * @return {[type]}            [description]
 */
function execute(data, callback) {
	console.log(data);
	if (typeof data == "string") {
		try {
			data = JSON.parse(data);
		} catch (excep) {
			delete data;
		}
	}
	validate_all(validate, data)
		.then(function (result) {
			console.log(result, 'create configrtor')
			return crateConfigrator(result);
		})
		.then(function (result) {
			response({ code: 200, body: result }, callback);
		})
		.catch(function (err) {
			response({ code: 400, err: { err } }, callback);
		})
}

/**
 * validate the data to the categories
 * @param  {[type]} data [description]
 * @return {[type]}      [description]
 */
function validate_all(validate, data) {
	return new Promise((resolve, reject) => {
		
		validate(data).then(function (res) {
			console.log(res);
			resolve(res);
		}).catch(function (err) {
			console.log(JSON.stringify(err, null, 6));
			reject(err.errors[0].dataPath + " " + err.errors[0].message);
		})
	})
}

/**
 * login
 * @param  {[type]} data data=> username,password,clientId,userpool,contextdata
 * @return {[type]}      resolve
 */
function crateConfigrator(data) {
	return new Promise((resolve, reject) => {
	
		var params = {
			TableName: database.Table[1].TableName,
			Item: {
			
					"floorNo":data.floorNo,
					"flatStatus" :data.flatStatus,
					"area": data.area,
					"flatId": (data.flatId).toLowerCase(),
					"buildingName":(data.buildingName).toLowerCase(),
					"flatType": data.flatType,
					"features" :(data.features),
					"active" :(data.active).toLowerCase(),
					"pricePerSquare" :data.pricePerSquare,
					"totalPrice" :data.totalPrice,
					"createdAt" :createdDate.toString(),
			},
			ConditionExpression: 'attribute_not_exists(flatId)'
		};
		console.log("Post data", params)
		docClient.put(params, function (err, data) {
			if (err) reject("flatId already exits or validation failed.") // an error occurred
			else
				data['success'] = "flat created successfully"
			resolve(data);           // successful response
		});

	});
}